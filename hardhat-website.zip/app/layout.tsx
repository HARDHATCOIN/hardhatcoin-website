import "./globals.css";
import React from "react";

export const metadata = {
  title: "$HARD — Built Different",
  description: "The meme coin for construction workers on Solana.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
