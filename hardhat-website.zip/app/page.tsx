import React from "react";

export default function Home() {
  return (
    <main className="min-h-screen bg-yellow-100 text-gray-900 p-6 font-sans">
      {/* Hero Section */}
      <section className="text-center py-12">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
          $HARD — Built Different
        </h1>
        <p className="mt-4 text-lg md:text-xl">
          The first meme coin for construction workers & the ones who never sell soft.
        </p>
        <a
          href="https://pump.fun"
          className="inline-block mt-6 text-lg bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-4 rounded-2xl"
        >
          Buy on pump.fun
        </a>
      </section>

      {/* About Section */}
      <section className="bg-white shadow-xl rounded-2xl p-8 mt-12 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">About $HARD</h2>
        <p className="text-base leading-relaxed">
          For the ones who clock in early, grind late, and keep their helmets on during the bear. $HARD is more than a meme — it's a tribute to every blue-collar degen on Solana.
        </p>
      </section>

      {/* Tokenomics */}
      <section className="mt-12 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Tokenomics</h2>
        <ul className="list-disc pl-5 text-base">
          <li>100% Community Supply</li>
          <li>No Presale. No Team Wallet.</li>
          <li>LP Burned. Contract Renounced.</li>
        </ul>
      </section>

      {/* Roadmap */}
      <section className="mt-12 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Roadmap</h2>
        <ul className="space-y-2 text-base">
          <li>🔨 Launch on Solana</li>
          <li>🚧 Meme Contest</li>
          <li>🧱 Telegram Growth</li>
          <li>🏗️ Builder Tools Drop</li>
          <li>🚀 CoinGecko + CMC Listing</li>
        </ul>
      </section>

      {/* Links */}
      <section className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Join the Jobsite</h2>
        <div className="flex flex-wrap justify-center gap-4">
          <a href="https://twitter.com" className="bg-gray-800 text-white px-5 py-2 rounded-xl">Twitter</a>
          <a href="https://t.me" className="bg-gray-800 text-white px-5 py-2 rounded-xl">Telegram</a>
          <a href="https://pump.fun" className="bg-yellow-600 text-white px-5 py-2 rounded-xl">pump.fun</a>
          <a href="https://dexscreener.com" className="bg-gray-800 text-white px-5 py-2 rounded-xl">Dexscreener</a>
        </div>
      </section>
    </main>
  );
}
